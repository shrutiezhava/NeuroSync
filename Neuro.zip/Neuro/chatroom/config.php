<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

class Database {
    private static ?mysqli $conn = null;

    public static function getConnection(): mysqli {
        if (self::$conn === null) {
            self::$conn = new mysqli('localhost', 'root', '', 'ajaxdb');
            
            if (self::$conn->connect_errno) {
                throw new RuntimeException(
                    "Database connection failed: " . self::$conn->connect_error
                );
            }
            
            self::$conn->set_charset('utf8mb4');
        }
        return self::$conn;
    }
}