<?php
require_once 'config.php';

// Check authentication (replace with your global auth)
if (!isset($_SESSION['user_id'])) {
    header("Location: /login"); // Redirect to your auth system
    exit();
}

// Get database connection
$conn = Database::getConnection();

// Update last activity
$stmt = $conn->prepare("UPDATE users SET last_activity = NOW() WHERE user_id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP 8.2 Chatroom</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="chat-container">
        <!-- [Your existing HTML structure] -->
    </div>

    <script type="module">
        // Modern JavaScript using ES modules
        import { ChatEngine } from './assets/chat-engine.js';
        
        const chat = new ChatEngine({
            userId: <?= json_encode($_SESSION['user_id']) ?>,
            userName: <?= json_encode($_SESSION['user_name']) ?>
        });
        
        chat.startPolling();
    </script>
</body>
</html>