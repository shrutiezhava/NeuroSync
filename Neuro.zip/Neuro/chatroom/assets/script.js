// Update messages every 2 seconds
setInterval(updateMessages, 2000);
setInterval(updateOnlineUsers, 3000);

// Initial load
updateMessages();
updateOnlineUsers();

document.getElementById('send-button').addEventListener('click', sendMessage);
document.getElementById('message-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

async function sendMessage() {
    const input = document.getElementById('message-input');
    const message = input.value.trim();
    
    if (message) {
        try {
            await fetch('/api/messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: message })
            });
            input.value = '';
        } catch (error) {
            console.error('Error sending message:', error);
        }
    }
}

async function updateMessages() {
    try {
        const response = await fetch('/api/messages.php');
        const messages = await response.json();
        
        const messagesContainer = document.getElementById('messages');
        messagesContainer.innerHTML = messages.map(msg => `
            <div class="message">
                <span class="sender">${msg.user_name}:</span>
                <span class="content">${msg.content}</span>
            </div>
        `).join('');
        
        // Auto-scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    } catch (error) {
        console.error('Error fetching messages:', error);
    }
}

async function updateOnlineUsers() {
    try {
        const response = await fetch('/api/users.php');
        const users = await response.json();
        
        document.getElementById('online-users').innerHTML = users.map(user => `
            <div class="${user.is_online ? 'online-user' : 'offline-user'}">
                ${user.user_name} ${user.is_online ? '🟢' : '⚫'}
            </div>
        `).join('');
    } catch (error) {
        console.error('Error fetching users:', error);
    }
}