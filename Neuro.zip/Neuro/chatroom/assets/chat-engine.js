export class ChatEngine {
    constructor({ userId, userName }) {
        this.userId = userId;
        this.userName = userName;
        this.pollingIntervals = [];
    }

    async #fetchData(endpoint) {
        try {
            const response = await fetch(`/api/${endpoint}.php`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error(`Fetch failed for ${endpoint}:`, error);
            return [];
        }
    }

    async #postData(endpoint, data) {
        await fetch(`/api/${endpoint}.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    }

    async updateMessages() {
        const messages = await this.#fetchData('messages');
        document.getElementById('messages').innerHTML = messages.map(msg => `
            <div class="message">
                <span class="sender">${msg.user_name}:</span>
                <span class="content">${msg.content}</span>
                <small>${new Date(msg.sent_at).toLocaleTimeString()}</small>
            </div>
        `).join('');
    }

    async updateUsers() {
        const users = await this.#fetchData('users');
        document.getElementById('online-users').innerHTML = users.map(user => `
            <div class="user ${user.is_online ? 'online' : 'offline'}">
                ${user.user_name}
                <span>${user.is_online ? '🟢' : '⚫'}</span>
            </div>
        `).join('');
    }

    async sendMessage(content) {
        await this.#postData('messages', { 
            user_id: this.userId,
            content 
        });
    }

    startPolling() {
        this.pollingIntervals.push(
            setInterval(() => this.updateMessages(), 2000),
            setInterval(() => this.updateUsers(), 3000)
        );
        
        document.getElementById('send-button').addEventListener('click', () => {
            const input = document.getElementById('message-input');
            this.sendMessage(input.value.trim());
            input.value = '';
        });
    }
}